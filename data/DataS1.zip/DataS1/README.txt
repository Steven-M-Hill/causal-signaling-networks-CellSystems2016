Hill, Nesser et al., "Phosphoprotein profiling reveals context-specificity in cancer cell line signaling". Submitted.

This folder contains the reverse-phase protein array data described in the above manuscript.

------------------------

"core" folder:
The folder named "core" contains the data used in the analyses presented in the manuscript. This comprises data for 35 phosphoprotein antibodies up to and including the 4 hour time point (i.e. 7 time points) for each of the cell lines, stimuli and kinase inhibitor regimes. File format is CSV and there is a separate file for each cell line. 
The CSV files contain 3 header rows:
- antibody name (see also Table S1)
- slide QC metric (where available, see Extended Experimental Procedures) 
- headings for metadata columns

The first 6 columns contain the following metadata:
- cell line
- stimulus
- inhibitor regime
- time point
- correction factor (CF) score from protein loading normalization (see Extended Experimental Procedures)
- binary value for each sample indicating whether it was excluded from analysis due to not passing quality control(see Extended Experimental Procedures and Table S6)

Abundance values are provided on a linear scale. Note that values are not directly comparable across antibodies and, due to potential batch effects, should not be directly compared across cell lines for a given antibody.

------------------------

"complete" folder:
The folder names "complete" contains all data. In particular, it includes antibodies and later time points not used in the analyses presented in the manuscript. File format is CSV and there is a separate file for each cell line.
The CSV files contain an additional 2 header rows to the "core" files (i.e. 5 header rows in total). The addional rows are:
- binary value for each antibody indicating whether it was used in the analyses presented in the manuscript
- binary value for each antibody indicating where it is for a phosphoprotein or a cleaved protein

The first 6 columns contain metadata. Columns are as for the "core" files except for the 6th column, which is:
- binary value for each sample indicating whether it was included in the analysis presented in the manuscript

The "complete" folder contains a subfolder "UACC812_batches". UACC812 data were split across two RPPA experiments. The two batches were combined and normalized to obtain a single data set for UACC812 (see Extended Experimental Procedures). The subfolder "UACC812_batches" contains the original UACC812 data for each batch.
